<script type="text/javascript">
var AjaxPlanEstudioDetalle={
    
}
</script>
