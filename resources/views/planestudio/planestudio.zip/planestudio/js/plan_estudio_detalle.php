<script type="text/javascript">
var AddEditPlanEstudioDetalle=0; //0: Editar | 1: Agregar
//var PlanEstudioDetalleG={id:0,facultad:"",estado:1}; // Datos Globales

$(document).ready(function() {
    //AjaxFacultad.Cargar(HTMLCargarFacultad);
});
</script>
